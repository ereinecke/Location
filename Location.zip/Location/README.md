# Location

Android tutorial app for Google's location services

Based on Udacity's Android Nanodegree elective course on Google Play Services.  
Displays latitude, longitude, altitude and results of activity recognition.
